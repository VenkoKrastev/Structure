﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Models
{
    internal class NaturalClimber : Climber
    {
        public NaturalClimber(string name, int stamina) : base(name, stamina)
        {
        }
    }
}
