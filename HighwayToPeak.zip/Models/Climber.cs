﻿using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Utilities.Messages;
using System.Text;

namespace HighwayToPeak.Models
{
    internal class Climber : IClimber
    {
        private string name;
        private int stamina;
        private readonly List<string> conqueredPeaks = new List<string>();  

        public Climber(string name, int stamina)
        {
            Name = name;
            Stamina = stamina;
        }

        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException(ExceptionMessages.ClimberNameNullOrWhiteSpace);
                }
                name = value;
            }
        }

        public int Stamina
        {
            get => stamina;
            set
            {
                if (value > 10)
                {
                    value = 10;
                }
                if (value < 0)
                {
                    value = 0;
                }
                stamina = value;
            }
        }

        public IReadOnlyCollection<string> ConqueredPeaks => conqueredPeaks.AsReadOnly();
        

        public void Climb(IPeak peak)
        {
            if (peak.DifficultyLevel == "Extreme")
            {
                 
            }
            else if (peak.DifficultyLevel == "Hard")
            {

            }
            else if (peak.DifficultyLevel == "Moderate")
            {

            }         
        }

        public void Rest(int daysCount)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.GetType().Name} - Name: {Name}, Stamina: {Stamina}");
            sb.AppendLine($"Peaks conquered: no peaks conquered /{ConqueredPeaks}");
            return sb.ToString().TrimEnd();
        }
    }
}
