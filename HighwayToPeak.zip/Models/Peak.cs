﻿using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Utilities.Messages;
using System.Text;

namespace HighwayToPeak.Models
{
    internal class Peak : IPeak
    {
        private string name;
        private int elevation;
        private string difficultyLevel;

        public Peak(string name, int elevation, string difficultyLevel)
        {
            this.Name = name;
            this.Elevation = elevation;
            this.DifficultyLevel = difficultyLevel;
        }

        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.PeakNameNullOrWhiteSpace);
                }
                name = value;
            }
        }

        public int Elevation
        {
            get => elevation;
            set
            {
                if (elevation <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.PeakElevationNegative);
                }
                elevation = value;
            }
        }

        public string DifficultyLevel
        {
            get => difficultyLevel;
            set
            {
                difficultyLevel = value;
                
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Peak: {Name} -> Elevation: {Elevation}, Difficulty: {DifficultyLevel}");

            return sb.ToString().TrimEnd();
        }

    }
    

    
}
