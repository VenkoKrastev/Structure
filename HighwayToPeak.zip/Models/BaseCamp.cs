﻿using HighwayToPeak.Models.Contracts;

namespace HighwayToPeak.Models
{
    internal class BaseCamp : IBaseCamp
    {
        public IReadOnlyCollection<string> Residents => throw new NotImplementedException();

        public void ArriveAtCamp(string climberName)
        {
            throw new NotImplementedException();
        }

        public void LeaveCamp(string climberName)
        {
            throw new NotImplementedException();
        }
    }
}
