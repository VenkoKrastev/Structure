﻿namespace HighwayToPeak.Models
{
    internal class OxygenClimber : Climber
    {
        public OxygenClimber(string name, int stamina) : base(name, stamina)
        {
            
        }
    }
}
