﻿using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighwayToPeak.Repositories
{
    internal class PeakRepository : IRepository<IPeak>
    {
        private List<IPeak> peaks = new List<IPeak>();
        public IReadOnlyCollection<IPeak> All => this.peaks.AsReadOnly();

        public void Add(IPeak model)
        {
            peaks.Add(model);   

        }

        public IPeak Get(string name)
        {
            return peaks.Find(p => p.Name == name);
        }
    }
}
