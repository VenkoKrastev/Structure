﻿using HighwayToPeak.Models.Contracts;
using HighwayToPeak.Repositories.Contracts;

namespace HighwayToPeak.Repositories
{
    internal class ClimberRepository : IRepository<IClimber>
    {
        private List<IClimber> climbers = new List<IClimber>();
        public IReadOnlyCollection<IClimber> All => this.climbers.AsReadOnly();

        public void Add(IClimber model)
        {
            climbers.Add(model);
        }

        public IClimber Get(string name)
        {
            return climbers.Find(c => c.Name == name);
        }
    }
}
